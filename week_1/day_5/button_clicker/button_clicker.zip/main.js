console.log("hello JS files connected")

function logOut(element){
    element.innerHTML = "Logout"
}

function removeButton(element){
    element.remove();
}